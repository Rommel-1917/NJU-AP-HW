#include<iostream>
#include"Number.h"
using namespace std;
void showNumber(const Number& number)
{
	
	
		for (int i = 0; i < number.length; i++)
		{
			
			cout <<number.num[i];
		}
		cout << endl;
	
}
