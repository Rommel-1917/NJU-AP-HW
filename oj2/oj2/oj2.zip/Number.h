#include<iostream>
#include<cmath>
using namespace std;
class Number
{
public:

	int num[100];
	int length;
	Number()
	{
		num[0]=0;
		length = 1;
		for (int i = 1; i < 100; i++)
		{
			num[i] = 0;
		}
	}
	Number(char* s, int l)
	{
		for (int i = 0; i < l; i++)
		{
			num[i] =s[i]-'0';
		
		}
		for (int i = l; i < 100; i++)
		{
			num[i] = 0;
		}
		length = l;
	}
	Number(const Number& number)
	{
		for (int i = 0; i < number.length; i++)
		{
			num[i] = number.num[i];
		}
		length = number.length;
		for (int i = length; i < 100; i++)
		{
			num[i] = 0;
		}
	}
	~Number()
	{

	}
	Number operator +(const Number& number)
	{
		Number temp;
		Number temp2;
		for (int i = 0; i < 99; i++)
		{
			temp.num[i] = 0;
		}
		temp.length = 0;
		if (num[0] == 0 && length == 1)
		{
			temp2 = number;
			
			return temp2;
		}
		if  (number.num[0] == 0 && number.length == 1)
		{
			temp2.length = length;
			for(int i=0;i<length;i++)
			temp2.num[i] = num[i];
			return temp2;
		}
		for (int i = 99,j=(length>number.length?length:number.length)-1; j >=0;i--,j--)
		{
			int r = num[j] + number.num[j]+ temp.num[i];
	/*		cout  << num[j] <<"+" << number.num[j]<<"="<<temp.num[i]<< endl;*/
			if (r >= 10)
			{
				temp.num[i] =r-10;
				temp.num[i - 1]++;
				temp.length+=2;
			}
		
			else
			{
				if (temp.num[i] == 0)
				{
					temp.num[i] = r;
					temp.length++;
			}
				else
					temp.num[i] = r;
			}
		}
		int k = temp.length;
		
		for (int j = 0; j < k; j++)
		{
			
			temp2.num[j] = temp.num[100- temp.length+j];
		}
		temp2.length = temp.length;
	
		return temp2;
	}
	Number operator *( const Number& number)
	{
		Number temp;
		Number temp2;
		if ((num[0] == 0 && length == 1) || (number.num[0] == 0 && number.length == 1))
		{
			temp2.length = 1;
			temp2.num[0] = 0;
			return temp2;
		}
		for (int i = 0; i < 99; i++)
		{
			temp.num[i] = 0;
		}
		int l= length+number.length-1;
		
		
		for (int i = number.length-1,k=0;i>=0;i--,k++)
		{
			for (int j = length-1,q=0; j>=0;q++,j--)
			{
				temp.num[k + q] += num[j] * number.num[i];
			}
		}
		
		for (int i = 0; i <l; i++) 
		{
			if (temp.num[i] > 9) 
			{
				temp.num[i + 1] += temp.num[i] / 10;
				temp.num[i] %= 10;
				
				if (i == l - 1 && temp.num[i + 1] != 0)
					l++;
			}
		}
		for (int i = l-1, j = 0; i >= 0; j++, i--)
		{
			temp2.num[j] = temp.num[i];
			
		}
		temp2.length = l;
		return temp2;
	}
		
		
			
		
	
	bool  operator <(const Number& number)
	{
		if (length > number.length)
		{
			return false;
		}
		if (length < number.length)
		{
			return true;
		}
		else
		{
			for (int i = 0; i < length; i++)
			{
				if (num[i] < number.num[i])
					return true;
			}
		}
		return false;
	}
	friend void showNumber(const Number& number);
};