#include<string>
#include<iostream>
using namespace std;
void analyse(string command,int level);
