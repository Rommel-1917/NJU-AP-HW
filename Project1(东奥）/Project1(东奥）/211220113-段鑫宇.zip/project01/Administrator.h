#include<string>
using namespace std;
	bool Admin_Login();
	void Admin_menu();
	void Admin_all_User();
	void Admin_all_Good();
	void Admin_all_Order();
	void Admin_Deluser(string id);
	void Admin_Delgood(string id);
	void menu();
	void Admin_Search(string name);
